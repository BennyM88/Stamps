package jp.gr.java_conf.androtaku.geomap;

/**
 * Created by takuma on 2015/07/21.
 */
public interface OnInitializedListener {
    void onInitialized(GeoMapView geoMapView);
}
