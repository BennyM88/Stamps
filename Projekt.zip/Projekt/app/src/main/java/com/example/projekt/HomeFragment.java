package com.example.projekt;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.projekt.country.CountryFragment;
import com.example.projekt.db.AppDatabase;
import com.example.projekt.db.CountryDB;

import java.util.List;


public class HomeFragment extends Fragment
{
    TextView textView;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        textView = (TextView) view.findViewById(R.id.textViewCounter);
        AppDatabase.getInstance().getCountryDAO().getLiveDataWithAllCountries().observe(getViewLifecycleOwner(), this::fillUI);
        return view;
    }

    private void fillUI(List<CountryDB> countryDBS) {
        int counter = 0;
        for(CountryDB countryDB: countryDBS) {
            if(countryDB.isWantToSee())
            {
                counter++;
            }
        }
        textView.setText(String.format("%d/%d", counter, countryDBS.size()));
    }
}
