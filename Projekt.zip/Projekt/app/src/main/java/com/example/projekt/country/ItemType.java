package com.example.projekt.country;

public interface ItemType {
    EItemType getType ();
}
