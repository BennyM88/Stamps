package com.example.projekt.country;

public enum EItemType {
    Header,
    Country
}
